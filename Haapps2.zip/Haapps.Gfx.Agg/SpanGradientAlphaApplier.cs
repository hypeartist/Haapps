﻿using System.Runtime.CompilerServices;
using Haapps.Utils.PodMemory;

namespace Haapps.Gfx.Agg
{
	public unsafe struct SpanGradientAlphaApplier<TColor> : ISpanGradientApplier<TColor, byte>
		where TColor : unmanaged, IColor
	{
		[MethodImpl(MethodImplOptions.AggressiveInlining|MethodImplOptions.AggressiveOptimization)]
		public void Apply(ref TColor* span, PodSpan<byte> applyData, int d) => span++->A = applyData[d];
	}
}