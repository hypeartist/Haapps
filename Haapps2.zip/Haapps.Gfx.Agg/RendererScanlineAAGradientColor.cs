﻿using System.Runtime.CompilerServices;

namespace Haapps.Gfx.Agg
{
	public unsafe struct RendererScanlineAAGradientColor<TRenderingBuffer, TColor, TRendererBaseColor, TSpanGeneratorColor> : IRendererScanline
		where TRenderingBuffer : unmanaged, IRenderingBuffer
		where TColor : unmanaged, IColor
		where TRendererBaseColor : unmanaged, IRendererBaseColor<TRenderingBuffer, TColor>
		where TSpanGeneratorColor : unmanaged, ISpanGenerator<TColor>
	{
		private readonly TSpanGeneratorColor* _generator;
		private readonly TRendererBaseColor* _renderer;

		public RendererScanlineAAGradientColor(ref TRendererBaseColor renderer, ref TSpanGeneratorColor generator)
		{
			_renderer = (TRendererBaseColor*) Unsafe.AsPointer(ref renderer);
			_generator = (TSpanGeneratorColor*) Unsafe.AsPointer(ref generator);
		}

		public void Prepare() => _generator->Prepare();

		public void Render<TScanline>(ref TScanline scanline) 
			where TScanline : unmanaged, IScanline => RenderScanline(ref scanline, ref *_renderer, ref *_generator);

		public static void RenderScanline<TScanline>(ref TScanline scanline, ref TRendererBaseColor renderer, ref TSpanGeneratorColor generator)
			where TScanline : unmanaged, IScanline
		{
			var y = scanline.Y;
			var spans = scanline.GetSpans(out var count);
			for (var i = 0; i < count; i++)
			{
				var span = spans[i];
				var x = span.X;
				var length = span.Length;
				{
					var colors = stackalloc TColor[length];
					generator.Generate(colors, x, y, length);
					renderer.BlendColorHSpan(x, y, length, colors, length < 0 ? null : span.Covers, *span.Covers);
				}
			}
		}

		public static void RenderScanlines<TRasterizerScanline, TScanline>(ref TRasterizerScanline rasterizer, ref TRendererBaseColor renderer, ref TSpanGeneratorColor generator)
			where TRasterizerScanline : unmanaged, IRasterizerScanline
			where TScanline : unmanaged, IScanline
		{
			if (!rasterizer.RewindScanlines())
			{
				return;
			}

			TScanline scanline = default;
			var maxLength = scanline.CalcMaxLength(rasterizer.MinX, rasterizer.MaxX);
			var slSpans = stackalloc Span[maxLength];
			var slCovers = stackalloc byte[maxLength];
			scanline.Reset(slCovers, slSpans);

			generator.Prepare();
			while (rasterizer.SweepScanline(ref scanline))
			{
				RenderScanline(ref scanline, ref renderer, ref generator);
			}
		}
	}
}