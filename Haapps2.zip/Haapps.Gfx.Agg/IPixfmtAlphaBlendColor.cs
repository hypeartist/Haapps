﻿namespace Haapps.Gfx.Agg
{
	public unsafe interface IPixfmtAlphaBlendColor<TRenderingBuffer, TColor> : IPixelDataAccessor<TRenderingBuffer>
		where TRenderingBuffer : unmanaged, IRenderingBuffer
		where TColor : unmanaged, IColor
	{
		TColor GetPixel(int x, int y);
		void SetPixel(int x, int y, TColor color);
		void BlendPixel(int x, int y, TColor color, byte cover);
		void CopyHLine(int x, int y, int length, TColor color);
		void CopyVLine(int x, int y, int length, TColor color);
		void BlendHLine(int x, int y, int length, TColor color, byte cover);
		void BlendVLine(int x, int y, int length, TColor color, byte cover);
		void BlendSolidHSpan(int x, int y, int length, TColor color, byte* covers);
		void BlendSolidVSpan(int x, int y, int length, TColor color, byte* covers);
		void CopyColorHSpan(int x, int y, int length, TColor* colors);
		void CopyColorVSpan(int x, int y, int length, TColor* colors);
		void BlendColorHSpan(int x, int y, int length, TColor* colors, byte* covers, byte cover);
		void BlendColorVSpan(int x, int y, int length, TColor* colors, byte* covers, byte cover);
		void BlendFromColor<TPixfmtAlphaBlend>(TPixfmtAlphaBlend src, TColor color, int xdst, int ydst, int xsrc, int ysrc, int length, byte cover)
			where TPixfmtAlphaBlend : unmanaged, IPixelDataAccessor<TRenderingBuffer>;
		void BlendFromLUT<TPixfmtAlphaBlend>(TPixfmtAlphaBlend src, TColor* colorLUT, int xdst, int ydst, int xsrc, int ysrc, int length, byte cover)
			where TPixfmtAlphaBlend : unmanaged, IPixelDataAccessor<TRenderingBuffer>;
		void BlendFrom<TPixfmtAlphaBlendColor>(TPixfmtAlphaBlendColor src, int xdst, int ydst, int xsrc, int ysrc, int length, byte cover)
			where TPixfmtAlphaBlendColor : unmanaged, IPixfmtAlphaBlendColor<TRenderingBuffer, TColor>;
	}
}