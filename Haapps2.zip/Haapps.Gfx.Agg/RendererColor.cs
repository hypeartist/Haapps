﻿using Haapps.Utils.PodMemory;

namespace Haapps.Gfx.Agg
{
	public static unsafe class RendererColor
	{
		public static void RenderScanlines<TRasterizerScanline, TScanline, TRendererScanline>(ref TRasterizerScanline rasterizer, ref TRendererScanline renderer)
			where TRasterizerScanline : unmanaged, IRasterizerScanline
			where TScanline : unmanaged, IScanline
			where TRendererScanline : unmanaged, IRendererScanline
		{
			if (!rasterizer.RewindScanlines())
			{
				return;
			}

			TScanline scanline = default;
			var maxLength = scanline.CalcMaxLength(rasterizer.MinX, rasterizer.MaxX);
			var slSpans = stackalloc Span[maxLength];
			var slCovers = stackalloc byte[maxLength];
			scanline.Reset(slCovers, slSpans);

			renderer.Prepare();
			while (rasterizer.SweepScanline(ref scanline))
			{
				renderer.Render(ref scanline);
			}
		}

		public static void RenderScanlines<TRenderingBuffer, TColor, TRasterizerScanline, TScanline, TRendererBaseColor, TSpanGeneratorColor>(ref TRasterizerScanline rasterizer, ref TRendererBaseColor renderer, ref TSpanGeneratorColor spanGenerator)
			where TRenderingBuffer : unmanaged, IRenderingBuffer
			where TColor : unmanaged, IColor
			where TRasterizerScanline : unmanaged, IRasterizerScanline
			where TScanline : unmanaged, IScanline
			where TRendererBaseColor : unmanaged, IRendererBaseColor<TRenderingBuffer, TColor>
			where TSpanGeneratorColor : unmanaged, ISpanGenerator<TColor>
		{
			if (!rasterizer.RewindScanlines())
			{
				return;
			}

			TScanline scanline = default;
			var maxLength = scanline.CalcMaxLength(rasterizer.MinX, rasterizer.MaxX);
			var slSpans = stackalloc Span[maxLength];
			var slCovers = stackalloc byte[maxLength];
			scanline.Reset(slCovers, slSpans);
		
			spanGenerator.Prepare();
			while (rasterizer.SweepScanline(ref scanline))
			{
				RendererScanlineAAGradientColor<TRenderingBuffer, TColor, TRendererBaseColor, TSpanGeneratorColor>.RenderScanline(ref scanline, ref renderer, ref spanGenerator);
			}
		}
	}
}