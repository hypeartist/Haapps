﻿using System;
using System.Runtime.CompilerServices;
using Haapps.Utils.PodMemory;

namespace Haapps.Gfx.Agg
{
	public sealed class RasterizerData<TCell> : IDisposable
		where TCell : unmanaged, ICell<TCell>
	{
		private StackList<TCell> _cells = new StackList<TCell>(128);
		private StackArray<SortedY> _sortedY = new StackArray<SortedY>(128);
		private StackArray<PodPtr<TCell>> _sortedCells = new StackArray<PodPtr<TCell>>(128);

		public ref StackList<TCell> Cells => ref _cells;

		public ref StackArray<SortedY> SortedY => ref _sortedY;

		public ref StackArray<PodPtr<TCell>> SortedCells => ref _sortedCells;

		// [MethodImpl(MethodImplOptions.AggressiveInlining|MethodImplOptions.AggressiveOptimization)]
		// public void Reset()
		// {
		// 	_cells.Clear();
		// 	if (_sortedCells != null)
		// 	{
		// 		PodHeap.Free(_sortedCells);
		// 	}
		// 	_sortedCells = null;
		// }
		//
		// [MethodImpl(MethodImplOptions.AggressiveInlining|MethodImplOptions.AggressiveOptimization)]
		// public void AddCell(ref TCell cell) => _cells.Add(ref cell);
		//
		// public int CellsCount
		// {
		// 	[MethodImpl(MethodImplOptions.AggressiveInlining|MethodImplOptions.AggressiveOptimization)]
		// 	get => _cells.Count;
		// }
		//
		// public int SortedYCount
		// {
		// 	[MethodImpl(MethodImplOptions.AggressiveInlining|MethodImplOptions.AggressiveOptimization)]
		// 	get => _sortedY.Size;
		// }
		//
		// public TCell* Cells
		// {
		// 	[MethodImpl(MethodImplOptions.AggressiveInlining|MethodImplOptions.AggressiveOptimization)]
		// 	get => _cells.DataPtr;
		// }
		//
		// public SortedY* SortedY
		// {
		// 	[MethodImpl(MethodImplOptions.AggressiveInlining|MethodImplOptions.AggressiveOptimization)]
		// 	get => _sortedY.DataPtr;
		// }
		//
		// public TCell** SortedCells
		// {
		// 	[MethodImpl(MethodImplOptions.AggressiveInlining|MethodImplOptions.AggressiveOptimization)]
		// 	get => _sortedCells;
		// }
		//
		// [MethodImpl(MethodImplOptions.AggressiveInlining|MethodImplOptions.AggressiveOptimization)]
		// public void PrepareForSorting(int minY, int maxY)
		// {
		// 	_sortedY.Reallocate(maxY - minY + 1);
		// 	_sortedY.Zero();
		// 	if (_sortedCells != null)
		// 	{
		// 		PodHeap.Free(_sortedCells);
		// 	}
		// 	_sortedCells = null;
		// 	_sortedCells = (TCell**) PodHeap.AllocateRaw(_cells.Count * sizeof(TCell*));
		// }

		public void Dispose()
		{
			_cells.Dispose();
			_sortedY.Dispose();
			_sortedCells.Dispose();
		}
	}
}