﻿namespace Haapps.Gfx.Agg
{
	public interface IOrderColor
	{
	}
}