﻿using System.Runtime.CompilerServices;

namespace Haapps.Gfx.Agg
{
	public unsafe struct PixfmtAlphaMaskAdaptor<TRenderingBuffer, TColor, TPixfmtAlphaBlendColor, TAlphaMask> : IPixfmtAlphaBlendColor<TRenderingBuffer, TColor>
		where TRenderingBuffer : unmanaged, IRenderingBuffer
		where TColor : unmanaged, IColor
		where TPixfmtAlphaBlendColor : unmanaged, IPixfmtAlphaBlendColor<TRenderingBuffer, TColor>
		where TAlphaMask : unmanaged, IAlphaMask
	{
		private readonly TPixfmtAlphaBlendColor* _pixfmt;
		private readonly TAlphaMask* _alphaMask;

		public PixfmtAlphaMaskAdaptor(TPixfmtAlphaBlendColor* pixfmt, TAlphaMask* alphaMask)
		{
			_pixfmt = pixfmt;
			_alphaMask = alphaMask;
		}

		public int BytesPerPixel => _pixfmt->BytesPerPixel;

		public int Width => _pixfmt->Width;

		public int Height => _pixfmt->Height;
		
		public int Stride => _pixfmt->Stride;

		public readonly byte* GetRowPtr(int y) => _pixfmt->GetRowPtr(y);

		public readonly byte* GetPixPtr(int x, int y) => _pixfmt->GetPixPtr(x, y);
		
		public readonly RowInfo GetRowInfo(int y) => _pixfmt->GetRowInfo(y);

		public readonly void Attach(TRenderingBuffer* buffer) => _pixfmt->Attach(buffer);

		public readonly bool Attach<TPixfmtAlphaBlend>(TPixfmtAlphaBlend* pixfmt, int x1, int y1, int x2, int y2) 
			where TPixfmtAlphaBlend : unmanaged, IPixelDataAccessor<TRenderingBuffer> => _pixfmt->Attach(pixfmt, x1, y1, x2, y2);

		public readonly TColor GetPixel(int x, int y) => _pixfmt->GetPixel(x, y);
		
		public readonly void SetPixel(int x, int y, TColor color) => _pixfmt->SetPixel(x, y, color);

		public readonly void BlendPixel(int x, int y, TColor color, byte cover)
		{
			_pixfmt->BlendPixel(x, y, color, _alphaMask->CombinePixel(x, y, cover));
		}

		public readonly void CopyHLine(int x, int y, int length, TColor c)
		{
			var _span = stackalloc byte[length];
			_alphaMask->FillHSpan(x, y, _span, length);
			_pixfmt->BlendSolidHSpan(x, y, length, c, _span);
		}

		public readonly void CopyVLine(int x, int y, int length, TColor c)
		{
			var _span = stackalloc byte[length];
			_alphaMask->FillVSpan(x, y, _span, length);
			_pixfmt->BlendSolidVSpan(x, y, length, c, _span);
		}

		public readonly void BlendHLine(int x, int y, int length, TColor c, byte cover)
		{
			var _span = stackalloc byte[length];
			Unsafe.InitBlock(_span, 255, (uint) length);
			_alphaMask->CombineHSpan(x, y, _span, length);
			_pixfmt->BlendSolidHSpan(x, y, length, c, _span);
		}

		public readonly void BlendVLine(int x, int y, int length, TColor c, byte cover)
		{
			var _span = stackalloc byte[length];
			Unsafe.InitBlock(_span, 255, (uint) length);
			_alphaMask->CombineVSpan(x, y, _span, length);
			_pixfmt->BlendSolidVSpan(x, y, length, c, _span);
		}

		public readonly void BlendSolidHSpan(int x, int y, int length, TColor c, byte* covers)
		{
			var _span = stackalloc byte[length];
			Unsafe.InitBlock(_span, 255, (uint) length);
			_alphaMask->CombineHSpan(x, y, _span, length);
			_pixfmt->BlendSolidHSpan(x, y, length, c, _span);
		}

		public readonly void BlendSolidVSpan(int x, int y, int length, TColor c, byte* covers)
		{
			var _span = stackalloc byte[length];
			Unsafe.InitBlock(_span, 255, (uint) length);
			_alphaMask->CombineVSpan(x, y, _span, length);
			_pixfmt->BlendSolidVSpan(x, y, length, c, _span);
		}

		public readonly void CopyColorHSpan(int x, int y, int length, TColor* colors)
		{
			var _span = stackalloc byte[length];
			_alphaMask->FillHSpan(x, y, _span, length);
			_pixfmt->BlendColorHSpan(x, y, length, colors, _span, 255);
		}

		public readonly void CopyColorVSpan(int x, int y, int length, TColor* colors)
		{
			var _span = stackalloc byte[length];
			_alphaMask->FillVSpan(x, y, _span, length);
			_pixfmt->BlendColorVSpan(x, y, length, colors, _span, 255);
		}

		public readonly void BlendColorHSpan(int x, int y, int length, TColor* colors, byte* covers, byte cover)
		{
			var _span = stackalloc byte[length];
			if (covers != null)
			{
				Unsafe.InitBlock(_span, 255, (uint) length);
				_alphaMask->CombineHSpan(x, y, _span, length);
			}
			else
			{
				_alphaMask->FillHSpan(x, y, _span, length);
			}
			_pixfmt->BlendColorHSpan(x, y, length, colors, _span, cover);
		}

		public readonly void BlendColorVSpan(int x, int y, int length, TColor* colors, byte* covers, byte cover)
		{
			var _span = stackalloc byte[length];
			if (covers != null)
			{
				Unsafe.InitBlock(_span, 255, (uint) length);
				_alphaMask->CombineVSpan(x, y, _span, length);
			}
			else
			{
				_alphaMask->FillVSpan(x, y, _span, length);
			}
			_pixfmt->BlendColorVSpan(x, y, length, colors, _span, cover);
		}

		public readonly void BlendFromColor<TPixfmtAlphaBlend>(TPixfmtAlphaBlend src, TColor color, int xdst, int ydst, int xsrc, int ysrc, int length, byte cover)
			where TPixfmtAlphaBlend : unmanaged, IPixelDataAccessor<TRenderingBuffer>
		{
			_pixfmt->BlendFromColor(src, color, xdst, ydst, xsrc, ysrc, length, cover);
		}

		public readonly void BlendFromLUT<TPixfmtAlphaBlend>(TPixfmtAlphaBlend src, TColor* colorLUT, int xdst, int ydst, int xsrc, int ysrc, int length, byte cover)
			where TPixfmtAlphaBlend : unmanaged, IPixelDataAccessor<TRenderingBuffer>
		{

		}

		public readonly void BlendFrom<TPixfmtAlphaBlendColor2>(TPixfmtAlphaBlendColor2 src, int xdst, int ydst, int xsrc, int ysrc, int length, byte cover)
			where TPixfmtAlphaBlendColor2 : unmanaged, IPixfmtAlphaBlendColor<TRenderingBuffer, TColor>
		{

		}
	}
}