﻿using System.Runtime.CompilerServices;
using Haapps.Utils.PodMemory;

namespace Haapps.Gfx.Agg
{
	public unsafe struct SpanGradientApplier<TColor> : ISpanGradientApplier<TColor, TColor>
		where TColor : unmanaged, IColor
	{
		[MethodImpl(MethodImplOptions.AggressiveInlining|MethodImplOptions.AggressiveOptimization)]
		public void Apply(ref TColor* span, PodSpan<TColor> applyData, int d) => *span++ = applyData[d];
	}
}