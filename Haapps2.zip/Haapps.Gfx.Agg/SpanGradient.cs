﻿using System.Runtime.CompilerServices;
using Haapps.Utils.PodMemory;

namespace Haapps.Gfx.Agg
{
	public unsafe struct SpanGradient<TColor, TApplyDataItem, TSpanGradientApplier, TTransform, TSpanInterpolator, TGradientFunction> : ISpanGenerator<TColor>
		where TColor : unmanaged, IColor
		where TApplyDataItem : unmanaged
		where TSpanGradientApplier : unmanaged, ISpanGradientApplier<TColor, TApplyDataItem>
		where TTransform : unmanaged, ITransform
		where TSpanInterpolator : unmanaged, ISpanInterpolator<TTransform>
		where TGradientFunction : unmanaged, IGradientFunction
	{
		private const int DownscaleShift = 8 - Common.GradientSubpixelShift;
		
		private readonly PodSpan<TApplyDataItem> _applyData;
		private readonly TSpanInterpolator* _interpolator;
		private int _d1;
		private int _d2;

		public SpanGradient(ref TSpanInterpolator interpolator, PodSpan<TApplyDataItem> applyData, double d1, double d2)
		{
			_interpolator = (TSpanInterpolator*) Unsafe.AsPointer(ref interpolator);
			_applyData = applyData;
			_d1 = Common.RoundToI32(d1 * Common.GradientSubpixelScale);
			_d2 = Common.RoundToI32(d2 * Common.GradientSubpixelScale);
		}

		public void Init(double d1, double d2)
		{
			_d1 = Common.RoundToI32(d1 * Common.GradientSubpixelScale);
			_d2 = Common.RoundToI32(d2 * Common.GradientSubpixelScale);
		}

		public void Prepare()
		{
		}

		[MethodImpl(MethodImplOptions.AggressiveInlining|MethodImplOptions.AggressiveOptimization)]
		public void Generate(TColor* span, int x, int y, int length)
		{
			var dd = _d2 - _d1;
			if (dd < 1)
			{
				dd = 1;
			}

			TGradientFunction gradientFunction = default;
			TSpanGradientApplier gradientApplier = default;
			_interpolator->Begin(x + 0.5, y + 0.5, length);
			do
			{
				_interpolator->Coordinates(out x, out y);
				var d = gradientFunction.Execute(x >> DownscaleShift, y >> DownscaleShift, _d2);
				d = (d - _d1) * _applyData.Size / dd;
				if (d < 0)
				{
					d = 0;
				}

				if (d >= _applyData.Size)
				{
					d = _applyData.Size - 1;
				}
				gradientApplier.Apply(ref span, _applyData, d);
				_interpolator->Inc();
			} while (--length != 0);
		}
	}
}