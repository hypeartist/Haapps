﻿using System.Runtime.InteropServices;

namespace Haapps.Gfx.Agg
{
	[StructLayout(LayoutKind.Sequential, Size = 256)]
	public struct FixedSize256
	{
	}
}