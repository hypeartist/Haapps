﻿namespace Haapps.Gfx.Agg
{
	public enum FillingRule
	{
		FillNonZero,
		FillEvenOdd
	}
}