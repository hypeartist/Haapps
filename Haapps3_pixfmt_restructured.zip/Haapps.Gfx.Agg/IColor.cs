﻿namespace Haapps.Gfx.Agg
{
	public interface IColor
	{
		byte A { get; set; }
	}
}