﻿namespace Haapps.Gfx.Agg
{
	public interface IOrderColor24 : IOrderColor
	{
		int R { get; }
		int G { get; }
		int B { get; }
	}
}