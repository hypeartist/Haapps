namespace Haapps.Gfx.Agg
{
	public abstract class MarkersGeneratorAbstract : VertexGeneratorAbstract
	{
	}
}