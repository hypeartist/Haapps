﻿using System.Runtime.CompilerServices;

namespace Haapps.Gfx.Agg
{
	public unsafe struct PixfmtAlphaBlend24<TRenderingBuffer, TOrderColor, TBlenderColor> : IPixfmt<Color8>, IPixelDataSrcAttacher<TRenderingBuffer>, IPixelDataAccessorAttacher, IPixfmtAlphaBlend<Color8>
		where TRenderingBuffer : unmanaged, IRenderingBuffer
		where TOrderColor : unmanaged, IOrderColor24
		where TBlenderColor : unmanaged, IBlenderColor24<TOrderColor>
	{
		private static TBlenderColor _blender = default;
		private static readonly TOrderColor Order = default;

		private TRenderingBuffer* _buffer;

		public PixfmtAlphaBlend24(ref TRenderingBuffer buffer) => _buffer = (TRenderingBuffer*) Unsafe.AsPointer(ref buffer);

		public readonly int BytesPerPixel => _buffer->BytesPerPixel;

		public readonly int Width => _buffer->Width;

		public readonly int Height => _buffer->Height;

		public readonly int Stride => _buffer->Stride;

		public readonly byte* GetRowPtr(int y) => _buffer->GetRowPtr(y);

		public readonly byte* GetRowPtr(int x, int y, int length)  => _buffer->GetRowPtr(x, y, length);

		public readonly byte* GetPixPtr(int x, int y) => _buffer->GetPixPtr(x, y);

		public readonly RowInfo GetRowInfo(int y) => _buffer->GetRowInfo(y);
		
		public void Attach(ref TRenderingBuffer buffer) => _buffer = (TRenderingBuffer*) Unsafe.AsPointer(ref buffer);

		public bool Attach<TPixelDataAccessor>(ref TPixelDataAccessor pixfmt, int x1, int y1, int x2, int y2)
			where TPixelDataAccessor : unmanaged, IPixelDataAccessor
		{
			var r1 = new Rectangle32(x1, y1, x2, y2);
			var r2 = new Rectangle32(0, 0, pixfmt.Width - 1, pixfmt.Height - 1);
			if (!r1.Clip(ref r2))
			{
				return false;
			}
			var stride = pixfmt.Stride;
			_buffer->Attach(pixfmt.GetPixPtr(r1.X1, stride < 0 ? r1.Y2 : r1.Y1), (r1.X2 - r1.X1) + 1, (r1.Y2 - r1.Y1) + 1, stride);
			return true;
		}

		public readonly Color8 Pixel(int x, int y)
		{
			var p = _buffer->GetRowPtr(y) + x + x + x;
			return new Color8(p[Order.R], p[Order.G], p[Order.B]);
		}

		public readonly void CopyPixel(int x, int y, Color8 color)
		{
			var p = _buffer->GetRowPtr(y) + x + x + x;
			p[Order.R] = color.R;
			p[Order.G] = color.G;
			p[Order.B] = color.B;
		}

		public readonly void BlendPixel(int x, int y, Color8 color, byte cover)
		{
			var p = _buffer->GetRowPtr(x, y, 1) + x + x + x;
			CopyOrBlendPix(p, color, cover);
		}

		public readonly void CopyHLine(int x, int y, int length, Color8 color)
		{
			var p = _buffer->GetRowPtr(x, y, length) + x + x + x;

			do
			{
				p[Order.R] = color.R;
				p[Order.G] = color.G;
				p[Order.B] = color.B;
				p += 3;
			} while (--length != 0);
		}

		public readonly void CopyVLine(int x, int y, int length, Color8 color)
		{
			do
			{
				var p = _buffer->GetRowPtr(x, y++, 1) + x + x + x;

				p[Order.R] = color.R;
				p[Order.G] = color.G;
				p[Order.B] = color.B;
			} while (--length != 0);
		}

		public readonly void BlendHLine(int x, int y, int length, Color8 color, byte cover)
		{
			if (color.A == 0)
			{
				return;
			}

			var p = _buffer->GetRowPtr(x, y, length) + x + x + x;

			var alpha = (color.A * (cover + 1)) >> 8;
			if (alpha == Color8.BaseMask)
			{
				do
				{
					p[Order.R] = color.R;
					p[Order.G] = color.G;
					p[Order.B] = color.B;
					p += 3;
				} while (--length != 0);
			}
			else
			{
				if (cover == Common.CoverFull)
				{
					do
					{
						_blender.BlendPixel(p, color.R, color.G, color.B, alpha);
						p += 3;
					} while (--length != 0);
				}
				else
				{
					do
					{
						_blender.BlendPixel(p, color.R, color.G, color.B, alpha, cover);
						p += 3;
					} while (--length != 0);
				}
			}
		}

		public readonly void BlendVLine(int x, int y, int length, Color8 color, byte cover)
		{
			if (color.A == 0)
			{
				return;
			}

			var alpha = (color.A * (cover + 1)) >> 8;
			if (alpha == Color8.BaseMask)
			{
				do
				{
					var p = _buffer->GetRowPtr(x, y++, 1) + x + x + x;

					p[Order.R] = color.R;
					p[Order.G] = color.G;
					p[Order.B] = color.B;
				} while (--length != 0);
			}
			else
			{
				if (cover == Common.CoverFull)
				{
					do
					{
						var p = _buffer->GetRowPtr(x, y++, 1) + x + x + x;
						_blender.BlendPixel(p, color.R, color.G, color.B, alpha);
					} while (--length != 0);
				}
				else
				{
					do
					{
						var p = _buffer->GetRowPtr(x, y++, 1) + x + x + x;
						_blender.BlendPixel(p, color.R, color.G, color.B, alpha, cover);
					} while (--length != 0);
				}
			}
		}

		[MethodImpl(MethodImplOptions.AggressiveInlining|MethodImplOptions.AggressiveOptimization)]
		public readonly void BlendSolidHSpan(int x, int y, int length, Color8 color, byte* covers)
		{
			if (color.A == 0)
			{
				return;
			}

			var p = _buffer->GetRowPtr(x, y, length) + x + x + x;

			do
			{
				var alpha = (color.A * (*covers + 1)) >> 8;
				if (alpha == Color8.BaseMask)
				{
					p[Order.R] = color.R;
					p[Order.G] = color.G;
					p[Order.B] = color.B;
				}
				else
				{
					_blender.BlendPixel(p, color.R, color.G, color.B, alpha, *covers);
				}
				p += 3;
				covers++;
			} while (--length != 0);
		}

		public readonly void BlendSolidVSpan(int x, int y, int length, Color8 color, byte* covers)
		{
			if (color.A == 0)
			{
				return;
			}

			do
			{
				var p = _buffer->GetRowPtr(x, y++, 1) + x + x + x;
				var alpha = (color.A * (*covers + 1)) >> 8;
				if (alpha == Color8.BaseMask)
				{
					p[Order.R] = color.R;
					p[Order.G] = color.G;
					p[Order.B] = color.B;
				}
				else
				{
					_blender.BlendPixel(p, color.R, color.G, color.B, alpha, *covers);
				}

				covers++;
			} while (--length != 0);
		}

		[MethodImpl(MethodImplOptions.AggressiveInlining|MethodImplOptions.AggressiveOptimization)]
		public readonly void CopyColorHSpan(int x, int y, int length, Color8* colors)
		{
			var p = _buffer->GetRowPtr(x, y, length) + x + x + x;
			do
			{
				p[Order.R] = colors->R;
				p[Order.G] = colors->G;
				p[Order.B] = colors->B;
				p += 3;
				colors++;
			} while (--length != 0);
		}

		public readonly void CopyColorVSpan(int x, int y, int length, Color8* colors)
		{
			do
			{
				var p = _buffer->GetRowPtr(x, y++, 1) + x + x + x;
				p[Order.R] = colors->R;
				p[Order.G] = colors->G;
				p[Order.B] = colors->B;
				colors++;
			} while (--length != 0);
		}

		public readonly void BlendColorHSpan(int x, int y, int length, Color8* colors, byte* covers, byte cover)
		{
			var p = _buffer->GetRowPtr(x, y, length) + x + x + x;
			if (covers != null)
			{
				do
				{
					CopyOrBlendPix(p, *colors++, *covers++);
					p += 3;
				} while (--length != 0);
			}
			else
			{
				if (cover == Common.CoverFull)
				{
					do
					{
						CopyOrBlendPix(p, *colors++);
						p += 3;
					} while (--length != 0);
				}
				else
				{
					do
					{
						CopyOrBlendPix(p, *colors++, cover);
						p += 3;
					} while (--length != 0);
				}
			}
		}

		public readonly void BlendColorVSpan(int x, int y, int length, Color8* colors, byte* covers, byte cover)
		{
			if (covers != null)
			{
				do
				{
					var p = _buffer->GetRowPtr(y++) + x + x + x;
					CopyOrBlendPix(p, *colors++, *covers++);
				} while (--length != 0);
			}
			else
			{
				if (cover == Common.CoverFull)
				{
					do
					{
						var p = _buffer->GetRowPtr(y++) + x + x + x;
						CopyOrBlendPix(p, *colors++);
					} while (--length != 0);
				}
				else
				{
					do
					{
						var p = _buffer->GetRowPtr(y++) + x + x + x;
						CopyOrBlendPix(p, *colors++, cover);
					} while (--length != 0);
				}
			}
		}

		public readonly void BlendFromColor<TPixfmtAlphaBlend>(TPixfmtAlphaBlend src, Color8 color, int xdst, int ydst, int xsrc, int ysrc, int length, byte cover)
			where TPixfmtAlphaBlend : unmanaged, IPixelDataAccessor
		{
			var psrc = src.GetRowPtr(ysrc);
			if (psrc == null) return;
			
			var pdst = _buffer->GetRowPtr(ydst) + xdst * 3;
			do
			{
				CopyOrBlendPix(pdst, color, (byte) ((*psrc * cover + Color8.BaseMask) >> Color8.BaseShift));
				++psrc;
				pdst += 3;
			} while (--length != 0);
		}

		public readonly void BlendFromLUT<TPixfmtAlphaBlend>(TPixfmtAlphaBlend src, Color8* colorLUT, int xdst, int ydst, int xsrc, int ysrc, int length, byte cover)
			where TPixfmtAlphaBlend : unmanaged, IPixelDataAccessor
		{
			var psrc = src.GetRowPtr(ysrc);
			if (psrc == null) return;
			
			var pdst = _buffer->GetRowPtr(ydst) + xdst * 3;

			if (cover == Common.CoverFull)
			{
				do
				{
					var color = colorLUT[*psrc];
					_blender.BlendPixel(pdst, color.R, color.G, color.B, color.A);
					++psrc;
					pdst += 3;
				} while (--length != 0);
			}
			else
			{
				do
				{
					CopyOrBlendPix(pdst, colorLUT[*psrc], cover);
					++psrc;
					pdst += 3;
				} while (--length != 0);
			}
		}

		public readonly void BlendFrom<TPixfmtAlphaBlendColor>(TPixfmtAlphaBlendColor src, int xdst, int ydst, int xsrc, int ysrc, int length, byte cover)
			where TPixfmtAlphaBlendColor : unmanaged, IPixfmt<Color8>
		{
			var psrc = src.GetRowPtr(ysrc);
			if (psrc == null) return;
			psrc += xsrc * src.BytesPerPixel;
			var pdst = _buffer->GetRowPtr(ydst) + xdst + xdst + xdst;
			if (cover == Common.CoverFull)
			{
				do
				{
					var csrc = src.Pixel(xsrc, ysrc);
					var cdst = Pixel(xdst, ydst);
					if (csrc.A != 0)
					{
						if (csrc.A == Color8.BaseMask)
						{
							src.CopyPixel(xdst, ydst, cdst);
						}
						else
						{
							_blender.BlendPixel(pdst, csrc.R, csrc.G, csrc.B, csrc.A);
						}
					}
					psrc += src.BytesPerPixel;
					pdst += 3;
				} while (--length != 0);
			}
			else
			{
				do
				{
					var csrc = src.Pixel(xsrc, ysrc);
					CopyOrBlendPix(pdst, csrc, cover);
					psrc += src.BytesPerPixel;
					pdst += 3;
				} while (--length != 0);
			}
		}

		private static void CopyOrBlendPix(byte* p, Color8 color, byte cover = Common.CoverFull)
		{
			if (color.A == 0)
			{
				return;
			}

			if (cover == Common.CoverFull)
			{
				if (color.A == Color8.BaseMask)
				{
					p[Order.R] = color.R;
					p[Order.G] = color.G;
					p[Order.B] = color.B;
				}
				else
				{
					_blender.BlendPixel(p, color.R, color.G, color.B, color.A);
				}
			}
			else
			{
				var alpha = (color.A * (cover + 1)) >> 8;
				if (alpha == Color8.BaseMask)
				{
					p[Order.R] = color.R;
					p[Order.G] = color.G;
					p[Order.B] = color.B;
				}
				else
				{
					_blender.BlendPixel(p, color.R, color.G, color.B, alpha, cover);
				}
			}
		}
	}
}