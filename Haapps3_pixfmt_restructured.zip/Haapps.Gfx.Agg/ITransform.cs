﻿namespace Haapps.Gfx.Agg
{
	public interface ITransform
	{
		void Transform(ref double x, ref double y);
	}
}