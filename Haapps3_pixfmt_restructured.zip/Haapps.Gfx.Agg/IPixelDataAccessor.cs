﻿namespace Haapps.Gfx.Agg
{
	public unsafe interface IPixelDataAccessor
	{
		int BytesPerPixel { get; }
		int Width { get; }
		int Height { get; }
		int Stride { get; }
		byte* GetRowPtr(int y);
		byte* GetRowPtr(int x, int y, int length);
		byte* GetPixPtr(int x, int y);
		RowInfo GetRowInfo(int y);
		// void Attach(TRenderingBuffer* buffer);
		// bool Attach<TPixfmtAlphaBlend>(TPixfmtAlphaBlend* pixfmt, int x1, int y1, int x2, int y2)
		// 	where TPixfmtAlphaBlend : unmanaged, IPixfmtAlphaBlend<TRenderingBuffer>;
	}

	public interface IPixelDataSrcAttacher<TPixelDataSrc>
		where TPixelDataSrc : unmanaged
	{
		void Attach(ref TPixelDataSrc dataSrc);
	}

	public interface IPixelDataAccessorAttacher
	{
		bool Attach<TPixelDataAccessor>(ref TPixelDataAccessor src, int x1, int y1, int x2, int y2)
			where TPixelDataAccessor : unmanaged, IPixelDataAccessor;
	}
}