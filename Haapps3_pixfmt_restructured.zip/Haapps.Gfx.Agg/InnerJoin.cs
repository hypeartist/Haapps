﻿namespace Haapps.Gfx.Agg
{
	public enum InnerJoin
	{
		InnerBevel,
		InnerMiter,
		InnerJag,
		InnerRound
	}
}