﻿namespace Haapps.Gfx.Agg
{
	public unsafe struct Span
	{
		public int X;
		public int Length;
		public byte* Covers;
#if DEBUG
		public override string ToString() => $"X: {X}, Length: {Length}, Covers: {Covers->ToString("X8")}";
#endif
	}
}