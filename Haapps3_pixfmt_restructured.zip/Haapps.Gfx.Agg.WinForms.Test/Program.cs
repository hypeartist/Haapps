using System;
using System.Diagnostics;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Haapps.Gfx.Agg.WinForms.Test
{
	internal static class Program
	{
		/// <summary>
		///  The main entry point for the application.
		/// </summary>
		[STAThread]
		private unsafe static void Main()
		{
			// ShowArgList1(__arglist(5, 6.0, "abc"));

			Application.SetHighDpiMode(HighDpiMode.SystemAware);
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			Application.Run(new TestForm());
		}

		[MethodImpl(MethodImplOptions.AggressiveInlining)]
		public static void ShowArgList1(__arglist)
		{
			ArgIterator ai = new ArgIterator(__arglist);
			while (ai.GetRemainingCount() > 0)
			{
				TypedReference tr = ai.GetNextArg();
				Console.WriteLine(TypedReference.ToObject(tr));
			}
		}

		[StructLayout(LayoutKind.Sequential, Size = 256)]
		public struct FixedSize256
		{
		}

		public struct MyStruct
		{
			private FixedSize256 _gamma;
		}
	}
}
