﻿namespace Haapps.Gfx.Agg
{
	public sealed class ConvStroke<TMarkersGenerator, TVertexSource> : ConvAdaptorVcgenAbstract<VcgenStroke, TMarkersGenerator, TVertexSource>
		where TMarkersGenerator : MarkersGeneratorAbstract, new()
		where TVertexSource : VertexSourceAbstract
	{
		public ConvStroke(TVertexSource source) : base(source)
		{
		}

		public double Shorten
		{
			get => Generator.Shorten;

			set => Generator.Shorten = value;
		}

		public double MiterLimit
		{
			get => Generator.MiterLimit;

			set => Generator.MiterLimit = value;
		}

		public double InnerMiterLimit
		{
			get => Generator.InnerMiterLimit;

			set => Generator.InnerMiterLimit = value;
		}

		public double ApproximationScale
		{
			get => Generator.ApproximationScale;

			set => Generator.ApproximationScale = value;
		}

		public LineJoin LineJoin
		{
			get => Generator.LineJoin;

			set => Generator.LineJoin = value;
		}

		public LineCap LineCap
		{
			get => Generator.LineCap;

			set => Generator.LineCap = value;
		}

		public InnerJoin InnerJoin
		{
			get => Generator.InnerJoin;

			set => Generator.InnerJoin = value;
		}

		public double Width
		{
			get => Generator.Width;

			set => Generator.Width = value;
		}

		public double MiterLimitTheta
		{
			set => Generator.MiterLimitTheta = value;
		}
	}

	public struct ConvStrokeStr<TMarkersGenerator, TVertexSource> : IVertexSource
		where TMarkersGenerator : unmanaged, IMarkerGenerator
		where TVertexSource : unmanaged, IVertexSource
	{
		private VcgenStrokeStr _vcgenStroke;
		private TMarkersGenerator _markers;
		private ConvAdaptorVcgenStr<VcgenStrokeStr, TMarkersGenerator, TVertexSource> _adaptor;

		public ConvStrokeStr(VcgenStrokeData data, ref TVertexSource source) : this()
		{
			_markers = new TMarkersGenerator();
			_vcgenStroke = new VcgenStrokeStr(data);
			_adaptor = new ConvAdaptorVcgenStr<VcgenStrokeStr, TMarkersGenerator, TVertexSource>(ref _vcgenStroke, ref _markers, ref source);
		}

		public double Shorten
		{
			get => _adaptor.Generator.Shorten;

			set => _adaptor.Generator.Shorten = value;
		}

		public double MiterLimit
		{
			get => _adaptor.Generator.MiterLimit;

			set => _adaptor.Generator.MiterLimit = value;
		}

		public double InnerMiterLimit
		{
			get => _adaptor.Generator.InnerMiterLimit;

			set => _adaptor.Generator.InnerMiterLimit = value;
		}

		public double ApproximationScale
		{
			get => _adaptor.Generator.ApproximationScale;

			set => _adaptor.Generator.ApproximationScale = value;
		}

		public LineJoin LineJoin
		{
			get => _adaptor.Generator.LineJoin;

			set => _adaptor.Generator.LineJoin = value;
		}

		public LineCap LineCap
		{
			get => _adaptor.Generator.LineCap;

			set => _adaptor.Generator.LineCap = value;
		}

		public InnerJoin InnerJoin
		{
			get => _adaptor.Generator.InnerJoin;

			set => _adaptor.Generator.InnerJoin = value;
		}

		public double Width
		{
			get => _adaptor.Generator.Width;

			set => _adaptor.Generator.Width = value;
		}

		public double MiterLimitTheta
		{
			set => _adaptor.Generator.MiterLimitTheta = value;
		}

		public void Rewind(int pathId = 0) => _adaptor.Rewind(pathId);

		public PathCommand Vertex(ref double x, ref double y) => _adaptor.Vertex(ref x, ref y);
	}
}