﻿namespace Haapps.Gfx.Agg
{
	public enum LineJoin
	{
		MiterJoin = 0,
		MiterJoinRevert = 1,
		RoundJoin = 2,
		BevelJoin = 3,
		MiterJoinRound = 4
	}
}