﻿namespace Haapps.Gfx.Agg
{
	public interface IGradientFunction
	{
		int Execute(int x, int y, int d = 0);
	}
}