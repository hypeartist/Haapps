﻿namespace Haapps.Gfx.Agg
{
	public enum LineCap
	{
		Butt,
		Square,
		Round
	}
}