﻿namespace Haapps.Gfx.Agg
{
	public interface IGammaFunction
	{
		double Execute(double x);
	}
}