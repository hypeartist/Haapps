using Haapps.Utils.PodMemory;

namespace Haapps.Gfx.Agg
{
	public sealed class VcgenStrokeData
	{
		private StackList<Point64> _outVertices = new StackList<Point64>(128);
		private StackList<VertexDistance> _srcVertices = new StackList<VertexDistance>(128);

		public ref StackList<Point64> OutVertices => ref _outVertices;

		public ref StackList<VertexDistance> SrcVertices => ref _srcVertices;
	}
}