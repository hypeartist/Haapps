﻿using System;
using Haapps.Utils.PodMemory;

namespace Haapps.Gfx.Agg
{
	public sealed class RasterizerData<TCell> : IDisposable
		where TCell : unmanaged, ICell<TCell>
	{
		private StackList<TCell> _cells = new StackList<TCell>(128);
		private StackArray<SortedY> _sortedY = new StackArray<SortedY>(128);
		private StackArray<PodPtr<TCell>> _sortedCells = new StackArray<PodPtr<TCell>>(128);

		public ref StackList<TCell> Cells => ref _cells;

		public ref StackArray<SortedY> SortedY => ref _sortedY;

		public ref StackArray<PodPtr<TCell>> SortedCells => ref _sortedCells;

		public void Dispose()
		{
			_cells.Dispose();
			_sortedY.Dispose();
			_sortedCells.Dispose();
		}
	}
}