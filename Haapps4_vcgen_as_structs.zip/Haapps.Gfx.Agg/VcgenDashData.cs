using Haapps.Utils.PodMemory;

namespace Haapps.Gfx.Agg
{
	public sealed class VcgenDashData
	{
		private const int MaxDashes = 32;

		private StackList<VertexDistance> _srcVertices = new StackList<VertexDistance>(128);
		private StackArray<double> _dashes = new StackArray<double>(MaxDashes);

		public ref StackList<VertexDistance> SrcVertices => ref _srcVertices;
		
		public ref StackArray<double> Dashes => ref _dashes;
	}
}