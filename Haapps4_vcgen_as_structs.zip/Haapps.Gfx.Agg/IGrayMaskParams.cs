﻿namespace Haapps.Gfx.Agg
{
	public interface IGrayMaskParams<TOrderColor>
		where TOrderColor : struct, IOrderColor
	{
		int Step { get; }
		int Offset { get; }
	}
}