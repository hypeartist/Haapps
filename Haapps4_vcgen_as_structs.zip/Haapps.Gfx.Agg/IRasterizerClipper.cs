﻿namespace Haapps.Gfx.Agg
{
	public interface IRasterizerClipper<TRasConv>
		where TRasConv : unmanaged, IRasterizerConverter
	{
	}
}