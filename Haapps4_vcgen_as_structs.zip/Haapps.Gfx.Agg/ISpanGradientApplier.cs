﻿using Haapps.Utils.PodMemory;

namespace Haapps.Gfx.Agg
{
	public unsafe interface ISpanGradientApplier<TColor, TApplyDataItem>
		where TColor : unmanaged, IColor
		where TApplyDataItem : unmanaged
	{
		void Apply(ref TColor* span, PodSpan<TApplyDataItem> applyData, int d);
	}
}