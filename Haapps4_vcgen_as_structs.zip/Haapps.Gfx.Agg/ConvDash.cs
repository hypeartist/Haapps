﻿namespace Haapps.Gfx.Agg
{
	public sealed class ConvDash<TMarkersGenerator, TVertexSource> : ConvAdaptorVcgenAbstract<VcgenDash, TMarkersGenerator, TVertexSource>
		where TMarkersGenerator : MarkersGeneratorAbstract, new()
		where TVertexSource : VertexSourceAbstract
	{
		public ConvDash(TVertexSource source) : base(source)
		{
		}

		public double Shorten
		{
			get => Generator.Shorten;

			set => Generator.Shorten = value;
		}

		public void AddDash(double dashLen, double gapLen) => Generator.AddDash(dashLen, gapLen);

		public void DashStart(double ds) => Generator.DashStart(ds);

		public void RemoveAllDashes() => Generator.RemoveAllDashes();
	}

	public struct ConvDashStr<TMarkersGenerator, TVertexSource> : IVertexSource
		where TMarkersGenerator : unmanaged, IMarkerGenerator
		where TVertexSource : unmanaged, IVertexSource
	{
		private VcgenDashStr _vcgenDash;
		private TMarkersGenerator _markers;
		private ConvAdaptorVcgenStr<VcgenDashStr, TMarkersGenerator, TVertexSource> _adaptor;

		public ConvDashStr(VcgenDashData data, ref TVertexSource source)
		{
			_markers = new TMarkersGenerator();
			_vcgenDash = new VcgenDashStr(data);
			_adaptor = new ConvAdaptorVcgenStr<VcgenDashStr, TMarkersGenerator, TVertexSource>(ref _vcgenDash, ref _markers, ref source);
		}

		public double Shorten
		{
			get => _adaptor.Generator.Shorten;

			set => _adaptor.Generator.Shorten = value;
		}

		public void AddDash(double dashLen, double gapLen) => _adaptor.Generator.AddDash(dashLen, gapLen);

		public void DashStart(double ds) => _adaptor.Generator.DashStart(ds);

		public void RemoveAllDashes() => _adaptor.Generator.RemoveAllDashes();
		
		public void Rewind(int pathId = 0) => _adaptor.Rewind(pathId);

		public PathCommand Vertex(ref double x, ref double y) => _adaptor.Vertex(ref x, ref y);
	}
}