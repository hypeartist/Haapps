﻿namespace Haapps.Gfx.Agg
{
	public interface IRendererScanlineColor<TColor> : IRendererScanline
		where TColor : unmanaged, IColor
	{
		TColor Color { get; set; }
	}
}