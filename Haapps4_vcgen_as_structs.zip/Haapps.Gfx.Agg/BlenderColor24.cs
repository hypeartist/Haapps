﻿using System.Runtime.CompilerServices;

namespace Haapps.Gfx.Agg
{
	public readonly unsafe struct BlenderColor24<TOrderColor> : IBlenderColor24<TOrderColor>
		where TOrderColor : unmanaged, IOrderColor24
	{
		private static readonly TOrderColor order = default;

		[MethodImpl(MethodImplOptions.AggressiveInlining|MethodImplOptions.AggressiveOptimization)]		
		public void BlendPixel(byte* p, int r, int g, int b, int a)
		{
			ref var pdr = ref p[order.R];
			ref var pdg = ref p[order.G];
			ref var pdb = ref p[order.B];
			
			pdr = (byte) (pdr + (((r - pdr) * a) >> Color8.BaseShift));
			pdg = (byte) (pdg + (((g - pdg) * a) >> Color8.BaseShift));
			pdb = (byte) (pdb + (((b - pdb) * a) >> Color8.BaseShift));
		}

		[MethodImpl(MethodImplOptions.AggressiveInlining|MethodImplOptions.AggressiveOptimization)]
		public void BlendPixel(byte* p, int r, int g, int b, int a, int cover)
		{
			ref var pdr = ref p[order.R];
			ref var pdg = ref p[order.G];
			ref var pdb = ref p[order.B];
			
			pdr = (byte) (pdr + (((r - pdr) * a) >> Color8.BaseShift));
			pdg = (byte) (pdg + (((g - pdg) * a) >> Color8.BaseShift));
			pdb = (byte) (pdb + (((b - pdb) * a) >> Color8.BaseShift));
		}
	}
}