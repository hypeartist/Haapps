﻿using System;

namespace Haapps.Gfx.Agg
{
	public abstract class RasterizerCellsAbstract : IDisposable
	{
		public abstract void Dispose();

		public abstract void Line(int x1, int y1, int x2, int y2);
		public abstract void Line(double x1, double y1, double x2, double y2);
	}
}