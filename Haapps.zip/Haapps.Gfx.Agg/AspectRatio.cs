namespace Haapps.Gfx.Agg
{
	public enum AspectRatio
	{
		Stretch,
		Meet,
		Slice
	}
}