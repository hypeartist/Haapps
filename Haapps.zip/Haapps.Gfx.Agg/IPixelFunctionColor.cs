﻿namespace Haapps.Gfx.Agg
{
	public interface IPixelFunctionColor<TColor>
		where TColor : unmanaged, IColor
	{
		int Size { get; }
		TColor this[int index] { get; set; }
	}
}