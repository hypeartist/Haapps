﻿namespace Haapps.Gfx.Agg
{
	public interface IRendererScanline
	{
		void Render<TScanline>(ref TScanline scanline)
			where TScanline : unmanaged, IScanline;
		void Prepare();
	}
}