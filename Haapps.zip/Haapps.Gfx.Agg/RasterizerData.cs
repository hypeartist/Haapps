﻿using System;
using System.Runtime.CompilerServices;
using Haapps.Utils.PodMemory;

namespace Haapps.Gfx.Agg
{
	public sealed unsafe class RasterizerData<TCell> : IDisposable
		where TCell : unmanaged, ICell<TCell>
	{
		private readonly PodList<TCell> _cells = new PodList<TCell>(128);
		private readonly PodArray<SortedY> _sortedY = new PodArray<SortedY>(128);
		private TCell** _sortedCells;

		[MethodImpl(MethodImplOptions.AggressiveInlining|MethodImplOptions.AggressiveOptimization)]
		public void Reset()
		{
			_cells.Clear();
			if (_sortedCells != null)
			{
				PodHeap.Free(_sortedCells);
			}
			_sortedCells = null;
		}

		[MethodImpl(MethodImplOptions.AggressiveInlining|MethodImplOptions.AggressiveOptimization)]
		public void AddCell(ref TCell cell) => _cells.Add(ref cell);

		public int CellsCount
		{
			[MethodImpl(MethodImplOptions.AggressiveInlining|MethodImplOptions.AggressiveOptimization)]
			get => _cells.Count;
		}

		public int SortedYCount
		{
			[MethodImpl(MethodImplOptions.AggressiveInlining|MethodImplOptions.AggressiveOptimization)]
			get => _sortedY.Size;
		}

		public TCell* Cells
		{
			[MethodImpl(MethodImplOptions.AggressiveInlining|MethodImplOptions.AggressiveOptimization)]
			get => _cells.DataPtr;
		}

		public SortedY* SortedY
		{
			[MethodImpl(MethodImplOptions.AggressiveInlining|MethodImplOptions.AggressiveOptimization)]
			get => _sortedY.DataPtr;
		}

		public TCell** SortedCells
		{
			[MethodImpl(MethodImplOptions.AggressiveInlining|MethodImplOptions.AggressiveOptimization)]
			get => _sortedCells;
		}

		[MethodImpl(MethodImplOptions.AggressiveInlining|MethodImplOptions.AggressiveOptimization)]
		public void PrepareForSorting(int minY, int maxY)
		{
			_sortedY.Reallocate(maxY - minY + 1);
			_sortedY.Zero();
			if (_sortedCells != null)
			{
				PodHeap.Free(_sortedCells);
			}
			_sortedCells = null;
			_sortedCells = (TCell**) PodHeap.AllocateRaw(_cells.Count * sizeof(TCell*));
		}

		public void Dispose()
		{
			_cells.Dispose();
			_sortedY.Dispose();
			if (_sortedCells != null)
			{
				PodHeap.Free(_sortedCells);
			}
			_sortedCells = null;
		}
	}
}