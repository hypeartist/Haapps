﻿using System.Runtime.InteropServices;
using Haapps.Utils.PodMemory;

namespace Haapps.Gfx.Agg
{
	public abstract unsafe class RasterizerScanlineAAAbstract<TRasterizerConverter, TRasterizerClipper> : RasterizerScanlineAbstract
		where TRasterizerConverter : unmanaged, IRasterizerConverter
		where TRasterizerClipper : unmanaged, IRasterizerClipper<TRasterizerConverter>
	{
		protected enum Status
		{
			Initial,
			MoveTo,
			LineTo,
			Closed
		}

		protected static TRasterizerClipper Clipper = default;
		protected static TRasterizerConverter Converter = default;

		private readonly PodArray<byte> _gamma = new PodArray<byte>(256);
		private int _scanY;
		
		protected readonly RasterizerCellsAA<Cell> _outline = new RasterizerCellsAA<Cell>();
		protected Status _status = Status.Initial;

		protected RasterizerScanlineAAAbstract()
		{
			for (var i = 0; i < Common.AAScale; i++)
			{
				_gamma[i] = (byte) i;
			}
		}

		public IGammaFunction GammaFunction
		{
			set
			{
				for (var i = 0; i < Common.AAScale; i++)
				{
					var v = value.Execute((double) i / 255) * 255;
					_gamma[i] = (byte) Common.RoundToU32(v);
				}
			}
		}

		public sealed override int MinX => _outline.MinX;

		public sealed override int MinY => _outline.MinY;

		public sealed override int MaxX => _outline.MaxX;

		public sealed override int MaxY => _outline.MaxY;

		public FillingRule FillingRule { get; set; } = FillingRule.FillNonZero;

		public bool AutoClose { get; } = true;

		public sealed override byte ApplyGamma(byte cover) => _gamma[cover];

		private byte CalculateAlpha(int area)
		{
			var cover = area >> (Common.PolySubpixelShiftMul2 + 1 - Common.AAShift);

			if (cover < 0)
			{
				cover = -cover;
			}

			if (FillingRule == FillingRule.FillEvenOdd)
			{
				cover &= Common.AAMask2;
				if (cover > Common.AAScale)
				{
					cover = Common.AAScale2 - cover;
				}
			}

			if (cover > Common.AAMask)
			{
				cover = Common.AAMask;
			}

			return _gamma[cover];
		}

		public sealed override void Reset()
		{
			_outline.Reset();
			_status = Status.Initial;
		}

		public sealed override bool SweepScanline<TScanline>(ref TScanline sl, int misc = 0)
		{
			for (;;)
			{
				if (_scanY > _outline.MaxY)
				{
					return false;
				}

				sl.ResetSpans();

				var cells = _outline.ScanlineCells(_scanY, out var count);
				var cover = 0;

				while (count != 0)
				{
					var curCell = *cells;
					var x = curCell->X;
					var area = curCell->Area;
					byte alpha;

					cover += curCell->Cover;

					while (--count != 0)
					{
						curCell = *++cells;
						if (curCell->X != x) break;
						area += curCell->Area;
						cover += curCell->Cover;
					}

					if (area != 0)
					{
						alpha = CalculateAlpha((cover << (Common.PolySubpixelShift + 1)) - area);
						if (alpha != 0)
						{
							sl.AddCell(x, alpha);
						}
						x++;
					}

					if ((count == 0 || curCell->X <= x)) continue;
					alpha = CalculateAlpha(cover << (Common.PolySubpixelShift + 1));
					if (alpha != 0)
					{
						sl.AddSpan(x, curCell->X - x, alpha);
					}
				}

				if (!sl.IsEmpty)
				{
					break;
				}

				++_scanY;
			}

			sl.Finalize(_scanY);
			++_scanY;
			return true;
		}

		public sealed override bool RewindScanlines()
		{
			if (AutoClose)
			{
				ClosePolygon();
			}

			_outline.SortCells();
			if (_outline.IsEmpty)
			{
				return false;
			}

			_scanY = _outline.MinY;
			return true;
		}

		public abstract void ClipBox(double x1, double y1, double x2, double y2);
		public abstract void ClosePolygon();

		public sealed override void AddVertex(double x, double y, PathCommand cmd)
		{
			if (cmd.MoveTo())
			{
				MoveToD(x, y);
			}
			else if (cmd.Vertex())
			{
				LineToD(x, y);
			}
			else if (cmd.Closed())
			{
				ClosePolygon();
			}
		}

		public sealed override void AddPath(VertexSourceAbstract vs, int pathId = 0)
		{
			PathCommand cmd;
			vs.Rewind(pathId);
			if (_outline.IsSorted)
			{
				Reset();
			}

			double x = 0;
			double y = 0;
			while (!(cmd = vs.Vertex(ref x, ref y)).Stop())
			{
				AddVertex(x, y, cmd);
			}
		}

		public sealed override void Dispose()
		{
			_outline.Dispose();
			_gamma.Dispose();
		}
	}
}
