﻿namespace Haapps.Gfx.Agg
{
	public sealed class RasterizerScanlineAA64<TRasConv, TClip> : RasterizerScanlineAAAbstract<TRasConv, TClip>
		where TRasConv : struct, IRasterizerConverter64
		where TClip : struct, IRasterizerClipper64<TRasConv>
	{
		private double _startX;
		private double _startY;

		public override void ClipBox(double x1, double y1, double x2, double y2)
		{
			Reset();
			Clipper.ClipBox(Converter.Upscale(x1), Converter.Upscale(y1), Converter.Upscale(x2), Converter.Upscale(y2));
		}

		public override void ClosePolygon()
		{
			if (_status != Status.LineTo)
			{
				return;
			}

			Clipper.LineTo(_outline, _startX, _startY);
			_status = Status.Closed;
		}

		public override void MoveTo(int x, int y)
		{
			if (_outline.IsSorted)
			{
				Reset();
			}

			if (AutoClose)
			{
				ClosePolygon();
			}

			Clipper.MoveTo(_startX = Converter.Downscale(x), _startY = Converter.Downscale(y));
			_status = Status.MoveTo;
		}

		public override void LineTo(int x, int y)
		{
			Clipper.LineTo(_outline, Converter.Downscale(x), Converter.Downscale(y));
			_status = Status.LineTo;
		}

		public override void MoveToD(double x, double y)
		{
			if (_outline.IsSorted)
			{
				Reset();
			}

			if (AutoClose)
			{
				ClosePolygon();
			}

			Clipper.MoveTo(_startX = Converter.Upscale(x), _startY = Converter.Upscale(y));
			_status = Status.MoveTo;
		}

		public override void LineToD(double x, double y)
		{
			Clipper.LineTo(_outline, Converter.Upscale(x), Converter.Upscale(y));
			_status = Status.LineTo;
		}
	}
}