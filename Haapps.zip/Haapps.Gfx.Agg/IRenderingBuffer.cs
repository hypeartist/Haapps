﻿namespace Haapps.Gfx.Agg
{
	public unsafe interface IRenderingBuffer
	{
		byte* Data { get; }
		int Stride { get; }
		int StrideAbs { get; }
		int Width { get; }
		int Height { get; }
		void Attach(byte* data, int width, int height, int stride);
		byte* GetRowPtr(int x, int y, int length);
		byte* GetRowPtr(int y);
		RowInfo GetRowInfo(int y);
		void CopyFrom<TRenderingBuffer>(TRenderingBuffer src) 
			where TRenderingBuffer : unmanaged, IRenderingBuffer;
		void Clear(byte value);
	}
}