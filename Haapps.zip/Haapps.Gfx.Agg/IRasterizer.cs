﻿using Haapps.Utils.PodMemory;

namespace Haapps.Gfx.Agg
{
	public interface IRasterizer
	{
		void AddPath(RasterizerData<Cell> data, VertexSourceAbstract vs, int pathId = 0);
		void AddVertex(RasterizerData<Cell> data, double x, double y, PathCommand cmd);
		void MoveTo(RasterizerData<Cell> data, int x, int y);
		void LineTo(RasterizerData<Cell> data, int x, int y);
		void MoveToD(RasterizerData<Cell> data, double x, double y);
		void LineToD(RasterizerData<Cell> data, double x, double y);
	}
}