﻿using System;

namespace Haapps.Gfx.Agg
{
	public abstract class RasterizerAbstract : IDisposable
	{
		public abstract void AddPath(VertexSourceAbstract vs, int pathId = 0);
		public abstract void AddVertex(double x, double y, PathCommand cmd);
		public abstract void MoveTo(int x, int y);
		public abstract void LineTo(int x, int y);
		public abstract void MoveToD(double x, double y);
		public abstract void LineToD(double x, double y);
		public abstract void Dispose();
	}
}