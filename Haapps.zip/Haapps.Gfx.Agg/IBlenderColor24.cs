﻿namespace Haapps.Gfx.Agg
{
	public interface IBlenderColor24<TOrderColor> : IBlenderColor<TOrderColor>
		where TOrderColor : unmanaged, IOrderColor24
	{
	}
}