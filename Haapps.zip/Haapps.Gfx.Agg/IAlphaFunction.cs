﻿namespace Haapps.Gfx.Agg
{
	public interface IAlphaFunction
	{
		int Size { get; }
		byte this[int index] { get; set; }
	}
}