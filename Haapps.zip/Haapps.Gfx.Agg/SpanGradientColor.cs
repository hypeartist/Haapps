﻿using System.Runtime.CompilerServices;

namespace Haapps.Gfx.Agg
{
	public unsafe struct SpanGradientColor<TColor, TPixelFunctionColor, TTransform, TSpanInterpolator, TGradientFunction> : ISpanGeneratorColor<TColor>
		where TColor : unmanaged, IColor
		where TPixelFunctionColor : unmanaged, IPixelFunctionColor<TColor>
		where TTransform : unmanaged, ITransform
		where TSpanInterpolator : unmanaged, ISpanInterpolator<TTransform>
		where TGradientFunction : unmanaged, IGradientFunction
	{
		private const int DownscaleShift = 8 - Common.GradientSubpixelShift;
		private readonly TPixelFunctionColor* _colors;

		private readonly TSpanInterpolator* _interpolator;

		private int _d1;
		private int _d2;

		public SpanGradientColor(ref TSpanInterpolator interpolator, ref TPixelFunctionColor cf, double d1, double d2)
		{
			_interpolator = (TSpanInterpolator*) Unsafe.AsPointer(ref interpolator);
			_colors = (TPixelFunctionColor*) Unsafe.AsPointer(ref cf);
			_d1 = Common.RoundToI32(d1 * Common.GradientSubpixelScale);
			_d2 = Common.RoundToI32(d2 * Common.GradientSubpixelScale);
		}

		public void Init(double d1, double d2)
		{
			_d1 = Common.RoundToI32(d1 * Common.GradientSubpixelScale);
			_d2 = Common.RoundToI32(d2 * Common.GradientSubpixelScale);
		}

		public void Prepare()
		{
		}

		[MethodImpl(MethodImplOptions.AggressiveInlining|MethodImplOptions.AggressiveOptimization)]
		public void Generate(TColor* span, int x, int y, int length)
		{
			var dd = _d2 - _d1;
			if (dd < 1)
			{
				dd = 1;
			}

			TGradientFunction gradientFunction = default;
			_interpolator->Begin(x + 0.5, y + 0.5, length);
			do
			{
				_interpolator->Coordinates(out x, out y);
				var d = gradientFunction.Execute(x >> DownscaleShift, y >> DownscaleShift, _d2);
				d = (d - _d1) * _colors->Size / dd;
				if (d < 0)
				{
					d = 0;
				}

				if (d >= _colors->Size)
				{
					d = _colors->Size - 1;
				}

				*span++ = (*_colors)[d];
				_interpolator->Inc();
			} while (--length != 0);
		}
	}

	public unsafe struct ColorSet<TColor> : IPixelFunctionColor<TColor>
		where TColor : unmanaged, IColor
	{
		private readonly TColor* _data;
		private readonly int _size;

		public ColorSet(TColor* data, int size)
		{
			_size = size;
			_data = data;
		}

		public int Size => _size;

		public TColor this[int index]
		{
			get => _data[index];
			set => _data[index] = value;
		}
	}
}