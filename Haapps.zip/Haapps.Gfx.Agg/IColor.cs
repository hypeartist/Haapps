﻿namespace Haapps.Gfx.Agg
{
	public interface IColor
	{
	}
}