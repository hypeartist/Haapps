﻿namespace Haapps.Gfx.Agg
{
	public unsafe interface IPixfmtAlphaBlend<TRenderingBuffer>
		where TRenderingBuffer : unmanaged, IRenderingBuffer
	{
		int BytesPerPixel { get; }
		int Width { get; }
		int Height { get; }
		int Stride { get; }
		byte* GetRowPtr(int y);
		byte* GetPixPtr(int x, int y);
		RowInfo GetRowInfo(int y);
		void Attach(TRenderingBuffer* buffer);
		bool Attach<TPixfmtAlphaBlend>(TPixfmtAlphaBlend* pixfmt, int x1, int y1, int x2, int y2)
			where TPixfmtAlphaBlend : unmanaged, IPixfmtAlphaBlend<TRenderingBuffer>;
	}
}