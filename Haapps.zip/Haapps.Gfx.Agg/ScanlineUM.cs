﻿// using System;
// using System.Runtime.CompilerServices;
//
// namespace Haapps.Gfx.Agg
// {
// 	public sealed unsafe class ScanlineUM : ScanlineAbstract, IDisposable
// 	{
// 		private readonly AlphaMaskAbstract _alphaMask;
// 		private readonly PodArray<byte> _covers = new PodArray<byte>();
// 		private readonly PodArray<Span> _spans = new PodArray<Span>();
// 		private Span* _currentSpan;
// 		private int _lastX;
// 		private int _minX;
//
// 		public ScanlineUM(AlphaMaskAbstract mask) => _alphaMask = mask;
//
// 		public override int Y { get; protected set; }
//
// 		public override bool IsEmpty => (int) (_currentSpan - _spans) <= 0;
//
// 		public override bool IsHit => false;
//
// 		public void Dispose()
// 		{
// 			_covers?.Dispose();
// 			_spans?.Dispose();
// 		}
//
// 		public override void Reset(int minX, int maxX)
// 		{
// 			var maxLen = maxX - minX + 2;
// 			_spans.Reallocate(maxLen);
// 			_covers.Reallocate(maxLen);
// 			_lastX = 0x7FFFFFF0;
// 			_minX = minX;
// 			_currentSpan = _spans;
// 		}
//
// 		public override void AddCell(int x, byte cover)
// 		{
// 			var xx = x - _minX;
// 			_covers[xx] = cover;
// 			if (xx == _lastX + 1)
// 			{
// 				_currentSpan->Length++;
// 			}
// 			else
// 			{
// 				_currentSpan++;
// 				_currentSpan->X = xx + _minX;
// 				_currentSpan->Length = 1;
// 				_currentSpan->Covers = _covers.DataPtr + xx;
// 			}
//
// 			_lastX = xx;
// 		}
//
// 		public override void AddCells(int x, int length, byte* covers)
// 		{
// 			var xx = x - _minX;
// 			Unsafe.CopyBlock((_covers.DataPtr + xx), covers, (uint) length);
// 			if (xx == _lastX + 1)
// 			{
// 				_currentSpan->Length += length;
// 			}
// 			else
// 			{
// 				_currentSpan++;
// 				_currentSpan->X = xx + _minX;
// 				_currentSpan->Length = length;
// 				_currentSpan->Covers = _covers.DataPtr + xx;
// 			}
//
// 			_lastX = xx + length - 1;
// 		}
//
// 		public override void AddSpan(int x, int length, byte cover)
// 		{
// 			var xx = x - _minX;
// 			Unsafe.InitBlock((_covers.DataPtr + xx), cover, (uint) length);
// 			if (xx == _lastX + 1)
// 			{
// 				_currentSpan->Length += length;
// 			}
// 			else
// 			{
// 				_currentSpan++;
// 				_currentSpan->X = xx + _minX;
// 				_currentSpan->Length = length;
// 				_currentSpan->Covers = _covers.DataPtr + xx;
// 			}
//
// 			_lastX = xx + length - 1;
// 		}
//
// 		public override void ResetSpans()
// 		{
// 			_lastX = 0x7FFFFFF0;
// 			_currentSpan = _spans;
// 		}
//
// 		public override void Finalize(int spanY)
// 		{
// 			Y = spanY;
// 			if (_alphaMask == null)
// 			{
// 				return;
// 			}
//
// 			var span = _spans.DataPtr + 1;
// 			var count = (int) (_currentSpan - _spans);
// 			do
// 			{
// 				_alphaMask.CombineHSpan(span->X, Y, span->Covers, span->Length);
// 				++span;
// 			} while (--count != 0);
// 		}
//
// 		public override Span* GetSpans(out int count)
// 		{
// 			count = (int) (_currentSpan - _spans);
// 			return _spans.DataPtr + 1;
// 		}
// 	}
// }