﻿namespace Haapps.Gfx.Agg
{
	public abstract unsafe class RasterizerScanlineAbstract : RasterizerAbstract
	{
		public abstract int MinX { get; }
		public abstract int MinY { get; }
		public abstract int MaxX { get; }
		public abstract int MaxY { get; }
		public abstract byte ApplyGamma(byte cover);
		public abstract void Reset();
		public abstract bool SweepScanline<TScanline>(ref TScanline sl, int misc = 0)
			where TScanline : struct, IScanline;
		public abstract bool RewindScanlines();
	}
}