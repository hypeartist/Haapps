﻿using System;
using System.Runtime.CompilerServices;
using System.Text;

namespace Haapps.Utils.PodMemory
{
	public readonly unsafe struct PodWideString
	{
		public readonly char* Chars;
		public readonly int Length;

		public static PodWideString FromMangedString(string str)
		{
			PodWideString podStr = default;
			*(&(((PodWideString*) Unsafe.AsPointer(ref podStr))->Chars)) = (char*) PodHeap.AllocateRaw<char>(str.Length + 1);
			*(&(((PodAnsiString*) Unsafe.AsPointer(ref podStr))->Length)) = str.Length;
			Unsafe.CopyBlock(podStr.Chars, Unsafe.AsPointer(ref Unsafe.AsRef(in str.AsSpan()[0])), (uint) (str.Length * sizeof(char)));
			podStr.Chars[str.Length] = (char) 0;
			return podStr;
		}
	}

	public readonly unsafe struct PodAnsiString
	{
		public readonly byte* Chars;
		public readonly int Length;

		public static PodAnsiString FromMangedString(string str)
		{
			PodAnsiString podStr = default;
			*(&(((PodAnsiString*) Unsafe.AsPointer(ref podStr))->Chars)) = (byte*) PodHeap.AllocateRaw<byte>(str.Length + 1);
			*(&(((PodAnsiString*) Unsafe.AsPointer(ref podStr))->Length)) = str.Length;
			Unsafe.CopyBlock(podStr.Chars, Unsafe.AsPointer(ref Encoding.ASCII.GetBytes(str).AsSpan()[0]), (uint) str.Length);
			podStr.Chars[str.Length] = 0;
			return podStr;
		}
	}
}