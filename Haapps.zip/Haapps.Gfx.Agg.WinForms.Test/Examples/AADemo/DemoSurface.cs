﻿using System;
using System.Windows.Forms;
using Haapps.Gfx.Agg.WinForms.Controls;
using Haapps.Gfx.Agg.WinForms.Controls.Win32;

namespace Haapps.Gfx.Agg.WinForms.Test.Examples.AADemo
{
	public unsafe partial class DemoSurface : Surface
	{
		private readonly double[] _x = new double[3];
		private readonly double[] _y = new double[3];
		private double _dx;
		private double _dy;
		private int _idx;
		// private readonly PanelWidget _pnlControls;
		// private readonly SliderWidget _sldPixelSize;
		// private readonly SliderWidget _sldGamma;
		// private readonly RasterizerScanlineAAStr32<RasConv32, RasterizerSlClip32<RasConv32>> _rasterizer = new RasterizerScanlineAAStr32<RasConv32, RasterizerSlClip32<RasConv32>>();
		// private readonly ScanlineU _scanlineU = new ScanlineU();
		// private readonly RendererEnlarged _rendererEnlarged;
		// private RendererBaseColor<RenderingBuffer, Color8, PixfmtAlphaBlend24<RenderingBuffer, Bgr, BlenderColor24<Bgr>>> _rendererBaseColor;
		private readonly PathStorage _path = new PathStorage();
		private readonly ConvStroke<NullMarkers, PathStorage> _pathStroke;

		public DemoSurface()
		{
			InitializeComponent();

			PixelFormat = Pixmap.Format.BGR24;

			// _pnlControls = new PanelWidget(5, 5, 210, 60);
			//
			// _sldPixelSize = new SliderWidget(5, 5, 200);
			// _sldPixelSize.Range(8.0, 100.0);
			// _sldPixelSize.NumberOfSteps = 23;
			// _sldPixelSize.Value = 32;
			// _sldPixelSize.Label = "Pixel size: {0:0}";
			//
			// _sldGamma = new SliderWidget(5, 30, 200);
			// _sldGamma.Range(0.1, 3.0);
			// _sldGamma.Value = 1.2;
			// _sldGamma.Label = "Gamma: {0:0.0}";
			//
			// _pnlControls.AddWidget(_sldGamma);
			// _pnlControls.AddWidget(_sldPixelSize);
			//
			// AddWidget(_pnlControls);

			// var renBuf = RenderingBuffer;
			// var pixfmt = new PixfmtAlphaBlend24<RenderingBuffer, Bgr, BlenderColor24<Bgr>>(&renBuf);
			// _rendererBaseColor = new RendererBaseColor<RenderingBuffer, Color8, PixfmtAlphaBlend24<RenderingBuffer, Bgr, BlenderColor24<Bgr>>>(&pixfmt);
			// _rendererEnlarged = new RendererEnlarged(_rendererBaseColor, /*(int)_sldPixelSize.Value*/32);

			_pathStroke = new ConvStroke<NullMarkers, PathStorage>(_path) { Width = 1.0 };			

			_x[0] = 57 + 200;
			_y[0] = 100 + 200;
			_x[1] = 369 + 200;
			_y[1] = 170 + 200;
			_x[2] = 143 + 200;
			_y[2] = 310 + 200;
		}

		protected override void OnResize(EventArgs e)
		{
			// _rendererBaseColor.UpdateClipBox();
			// _pnlControls.Y = Height - _pnlControls.Height - 5;
		}

		protected override void OnPaint(PaintEventArgs e)
		{
			var pixfmt = new PixfmtAlphaBlend24<RenderingBuffer, Bgr, BlenderColor24<Bgr>>(ref RenderingBuffer);
			var rendererBaseColor = new RendererBaseColor<RenderingBuffer, Color8, PixfmtAlphaBlend24<RenderingBuffer, Bgr, BlenderColor24<Bgr>>>(ref pixfmt);

			rendererBaseColor.Clear(new Color8(255, 255, 255));

			var pixelSize = 32;//(int)_sldPixelSize.Value;
			var rendererEnlarged = new RendererEnlarged<RenderingBuffer, RendererBaseColor<RenderingBuffer, Color8, PixfmtAlphaBlend24<RenderingBuffer, Bgr, BlenderColor24<Bgr>>>>(ref rendererBaseColor, pixelSize);
			// _rendererEnlarged.PixelSize = pixelSize;
			//
			var rasterizer = new RasterizerScanlineAAStr32<RasConv32, RasterizerSlClip32<RasConv32>>();
			rasterizer.Init();
			rasterizer.ApplyGammaFunction(new GammaFunctions.Power(1.2));

			using var data = new RasterizerData<Cell>();

			rasterizer.Reset(data);
			rasterizer.MoveToD(data, _x[0] / pixelSize, _y[0] / pixelSize);
			rasterizer.LineToD(data, _x[1] / pixelSize, _y[1] / pixelSize);
			rasterizer.LineToD(data, _x[2] / pixelSize, _y[2] / pixelSize);

			rendererEnlarged.Color = new Color8(0, 0, 0);
			RendererColor.RenderScanlines<RasterizerScanlineAAStr32<RasConv32, RasterizerSlClip32<RasConv32>>, ScanlineU, RendererEnlarged<RenderingBuffer, RendererBaseColor<RenderingBuffer, Color8, PixfmtAlphaBlend24<RenderingBuffer, Bgr, BlenderColor24<Bgr>>>>>(data, ref rasterizer, ref rendererEnlarged);

			RendererScanlineAASolidColor<RenderingBuffer, Color8, RendererBaseColor<RenderingBuffer, Color8, PixfmtAlphaBlend24<RenderingBuffer, Bgr, BlenderColor24<Bgr>>>>.RenderScanlines<RasterizerScanlineAAStr32<RasConv32, RasterizerSlClip32<RasConv32>>, ScanlineP>(data, ref rasterizer, ref rendererBaseColor, new Color8(0, 0, 0));
			//
			_path.RemoveAll();
			_path.MoveTo(_x[0], _y[0]);
			_path.LineTo(_x[1], _y[1]);
			rasterizer.AddPath(data, _pathStroke);
			RendererScanlineAASolidColor<RenderingBuffer, Color8, RendererBaseColor<RenderingBuffer, Color8, PixfmtAlphaBlend24<RenderingBuffer, Bgr, BlenderColor24<Bgr>>>>.RenderScanlines<RasterizerScanlineAAStr32<RasConv32, RasterizerSlClip32<RasConv32>>, ScanlineU>(data, ref rasterizer, ref rendererBaseColor, new Color8(0, 150, 160, 200));
			
			_path.RemoveAll();
			_path.MoveTo(_x[1], _y[1]);
			_path.LineTo(_x[2], _y[2]);
			rasterizer.AddPath(data, _pathStroke);
			RendererScanlineAASolidColor<RenderingBuffer, Color8, RendererBaseColor<RenderingBuffer, Color8, PixfmtAlphaBlend24<RenderingBuffer, Bgr, BlenderColor24<Bgr>>>>.RenderScanlines<RasterizerScanlineAAStr32<RasConv32, RasterizerSlClip32<RasConv32>>, ScanlineU>(data, ref rasterizer, ref rendererBaseColor, new Color8(0, 150, 160, 200));
			
			_path.RemoveAll();
			_path.MoveTo(_x[2], _y[2]);
			_path.LineTo(_x[0], _y[0]);
			rasterizer.AddPath(data, _pathStroke);
			RendererScanlineAASolidColor<RenderingBuffer, Color8, RendererBaseColor<RenderingBuffer, Color8, PixfmtAlphaBlend24<RenderingBuffer, Bgr, BlenderColor24<Bgr>>>>.RenderScanlines<RasterizerScanlineAAStr32<RasConv32, RasterizerSlClip32<RasConv32>>, ScanlineU>(data, ref rasterizer, ref rendererBaseColor, new Color8(0, 150, 160, 200));
			
			
			//
			// // RenderControl(_scanlineU, _rendererBaseColor, _pnlControls);
			// RenderWidgets(_rendererBaseColor);
		}

		protected override void OnMouseMove(MouseEventArgs e)
		{
			if (e.Button == MouseButtons.Left)
			{
				var x = e.X;
				var y = e.Y;
				if (_idx == 3)
				{
					var dx = x - _dx;
					var dy = y - _dy;
					_x[1] -= _x[0] - dx;
					_y[1] -= _y[0] - dy;
					_x[2] -= _x[0] - dx;
					_y[2] -= _y[0] - dy;
					_x[0] = dx;
					_y[0] = dy;
					ForceRedraw();
					return;
				}

				if (_idx < 0) return;
				_x[_idx] = x - _dx;
				_y[_idx] = y - _dy;
				ForceRedraw();
			}
			else
			{
				OnMouseUp(e);
			}
		}

		protected override void OnMouseDown(MouseEventArgs e)
		{
			if (e.Button != MouseButtons.Left) return;
			var x = e.X;
			var y = e.Y;
			int i;
			for (i = 0; i < 3; i++)
			{
				if (!(Math.Sqrt((x - _x[i]) * (x - _x[i]) + (y - _y[i]) * (y - _y[i])) < 10.0)) continue;
				_dx = x - _x[i];
				_dy = y - _y[i];
				_idx = i;
				break;
			}
			if (i != 3) return;
			if (!Common.PointInTriangle(_x[0], _y[0], _x[1], _y[1], _x[2], _y[2], x, y)) return;
			_dx = x - _x[0];
			_dy = y - _y[0];
			_idx = 3;
		}

		protected override void OnMouseUp(MouseEventArgs e)
		{
			_idx = -1;
		}
		//
		// protected override void OnControlChanged()
		// {
		// 	ForceRedraw();
		// }
	}
}
