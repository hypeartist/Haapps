namespace Haapps.Gfx.Agg.WinForms.Test.Examples.AADemo
{
	public struct Square
	{
		public double Size;

		public Square(double size)
		{
			Size = size;
		}

		public void Draw<TRasterizerScanline, TScanline, TRenderingBuffer, TColor, TRendererBaseColor>(RasterizerData<Cell> data, ref TRasterizerScanline rasterizer, ref TRendererBaseColor renderer, TColor color, double x, double y)
			where TRasterizerScanline : unmanaged, IRasterizerScanline
			where TRenderingBuffer : unmanaged, IRenderingBuffer
			where TColor : unmanaged, IColor
			where TRendererBaseColor : unmanaged, IRendererBaseColor<TRenderingBuffer, TColor>	
			where TScanline  : unmanaged, IScanline
		{
			rasterizer.Reset(data);
			rasterizer.MoveToD(data, x * Size, y * Size);
			rasterizer.LineToD(data, x * Size + Size, y * Size);
			rasterizer.LineToD(data, x * Size + Size, y * Size + Size);
			rasterizer.LineToD(data, x * Size, y * Size + Size);
			RendererScanlineAASolidColor<TRenderingBuffer, TColor, TRendererBaseColor>.RenderScanlines<TRasterizerScanline, TScanline>(data, ref rasterizer, ref renderer, color);
		}
	}
}