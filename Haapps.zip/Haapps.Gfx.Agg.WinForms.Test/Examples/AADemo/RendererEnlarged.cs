﻿using System;
using System.Runtime.CompilerServices;

namespace Haapps.Gfx.Agg.WinForms.Test.Examples.AADemo
{
	public unsafe struct RendererEnlarged<TRenderingBuffer, TRendererBaseColor> : IRendererScanlineColor<Color8>
		where TRenderingBuffer : unmanaged, IRenderingBuffer
		where TRendererBaseColor : unmanaged, IRendererBaseColor<TRenderingBuffer, Color8>
	{
		private RasterizerScanlineAAStr32<RasConv32, RasterizerSlClip32<RasConv32>> _rasterizer;
		private readonly TRendererBaseColor* _renderer;
		private Square _square;

		public RendererEnlarged(ref TRendererBaseColor ren, double size) : this()
		{
			_renderer = (TRendererBaseColor*) Unsafe.AsPointer(ref ren);
			_square = new Square(size);
			_rasterizer = new RasterizerScanlineAAStr32<RasConv32, RasterizerSlClip32<RasConv32>>();
			_rasterizer.Init();
		}

		public double PixelSize
		{
			set => ((Square*) (Unsafe.AsPointer(ref _square)))->Size = value;
			get => _square.Size;
		}

		public Color8 Color { get; set; }

		public void Prepare()
		{
		}

		public void Render<TScanline>(ref TScanline scanline)
			where TScanline : unmanaged, IScanline
		{
			var data = new RasterizerData<Cell>();
			var y = scanline.Y;
			var spans = scanline.GetSpans(out var count);
			for (var i = 0; i < count; i++)
			{
				var span = spans[i];
				var x = span.X;
				var covers = span.Covers;
				var numPix = span.Length;
				for (var j = 0; j < numPix; j++)
				{
					var c = Color;
					c.A = (byte)((*covers++ * Color.A) >> 8);
					_square.Draw<RasterizerScanlineAAStr32<RasConv32, RasterizerSlClip32<RasConv32>>, ScanlineU, TRenderingBuffer, Color8, TRendererBaseColor>(data, ref _rasterizer, ref *_renderer, c, x, y);
					x++;
				}
			}
			data.Dispose();
		}
	}
}